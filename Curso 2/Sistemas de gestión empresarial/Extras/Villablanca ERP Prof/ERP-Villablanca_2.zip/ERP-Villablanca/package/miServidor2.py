from reactivex import create
import multiprocessing
from reactivex.scheduler import ThreadPoolScheduler
from reactivex import operators as ops
import random
import time


class servidorTemperaturas():
    def __init__(self):
        self.source = create(self.cogerTemperaturas)


    def cogerTemperaturas(self, observer, scheduler):
        for i in range(0, 100):
            valor = random.uniform(20, 50)
            #valor = random.randint(20, 50)
            observer.on_next(valor)
            time.sleep(random.randint(5, 100)*0.1)
