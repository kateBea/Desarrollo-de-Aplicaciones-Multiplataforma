import multiprocessing
import random
import time
from threading import current_thread

import reactivex
from reactivex.scheduler import ThreadPoolScheduler
from reactivex import operators as ops
import multiprocessing

class miServidorReactivo():
    def __init__(self):
        optimal_thread_count = multiprocessing.cpu_count()
        self.pool_scheduler = ThreadPoolScheduler(optimal_thread_count)
        


    def intense_calculation(self, value):
        time.sleep(random.randint(5,100)*0.1)
        return value
    
    