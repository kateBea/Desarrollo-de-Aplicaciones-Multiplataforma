from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.animation import FuncAnimation
import numpy as np
from matplotlib import pyplot
import matplotlib.pyplot as plt
from .herramientas import coloresAplicacion


class Grafica():
    def __init__(self, ventana, lista):
        self.ventana = ventana
        self.miLista = lista
        self.colores = coloresAplicacion()
        self.fig1 = plt.figure(facecolor=self.colores.Principal_Color, layout='constrained')
        self.fig1.suptitle("Temperaturas")
        self.ax1 = self.fig1.add_subplot()
        self.ax1.set_title('Grados', loc="left", fontstyle="oblique", fontsize="medium")
        self.ax1.plot(self.miLista)
        self.canvas = FigureCanvasTkAgg(self.fig1, master = self.ventana)
        self.canvas.get_tk_widget().pack()
        self.tiempoReal = FuncAnimation(self.fig1, self.cargarDatos, fargs=[self.miLista])
        
        
        
    def cargarDatos(self, frame, valores):
        self.ax1.clear()
        self.ax1.set_ylabel('Temperaturas')
        self.ax1.set_xlabel('Número de Medidas')
        self.ax1.plot(valores)
        self.canvas.draw()
        
        

        


