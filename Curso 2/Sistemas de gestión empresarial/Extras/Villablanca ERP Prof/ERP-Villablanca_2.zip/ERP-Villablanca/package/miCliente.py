#from threading import current_thread
import reactivex
from reactivex import operators as ops
from miServidor import miServidorReactivo


miservidor = miServidorReactivo()



reactivex.range(1,10).pipe(
    ops.map(lambda s: miservidor.intense_calculation(s)), ops.subscribe_on(miservidor.pool_scheduler)
).subscribe(
    on_next=lambda i: print("Temperatura: {0}".format(i)),
    on_error=lambda e: print(e),
    on_completed=lambda: print("Proceso 2 terminado"),
)


