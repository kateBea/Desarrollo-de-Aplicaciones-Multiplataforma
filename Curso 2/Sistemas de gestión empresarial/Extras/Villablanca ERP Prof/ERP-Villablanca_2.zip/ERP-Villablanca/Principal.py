'''Aplicación desarrollada el 25 de noviembre de 2023'''
'''como examen para segundo de Dam                   '''
'''I.E.S. Villablanca                                '''
'''Creado por Mario Santos                           '''

from package.VentanaPrincipal import ventanaPrincipal

wind = ventanaPrincipal(850,600)

wind.mainloop()

