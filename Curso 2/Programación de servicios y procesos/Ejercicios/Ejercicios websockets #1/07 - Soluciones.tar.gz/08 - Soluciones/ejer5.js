// Se debe instalar:
// npm install express-session cookie-parser

var express = require('express');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const app = express();
var expressWs = require('express-ws')(app);
app.use(cookieParser());
app.use(
  session({
    secret: "Contraseña",
    cookie: { maxAge: 30*1000 },
    saveUninitialized: false,
    resave: false
  })
)
app.use(express.static('public'));

app.get('/inicio', function(req,res) {
  req.session.iniciada = "Sesión iniciada" 
  res.send("Sesión iniciada")
})
app.get('/cierre', function(req,res) {
  req.session.ws.close()
  req.session.destroy() 
  res.send("Sesión cerrada")
})

app.ws('/', function(ws, req) {
  if(req.session.iniciada) {
    req.session.ws = ws
    ws.on('message', function(msg) {
      console.log(req.session.iniciada)
      console.log(msg);
      ws.send(msg)
    });
    ws.on('close', () => {
      console.log('Socket cerrado')
    })
  } else {
    ws.close()
  }
});
app.listen(8080);
