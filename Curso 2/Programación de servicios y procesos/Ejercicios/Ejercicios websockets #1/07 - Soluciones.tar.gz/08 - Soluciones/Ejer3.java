
/*
 Se necesita descargar la biblioteca javax.websocket-api.jar y tyrus-standalone-client-1.3.3.jar:
 https://tyrus.java.net/
 Se pueden descargar los archivos jar desde:
https://mvnrepository.com/artifact/org.glassfish.tyrus.bundles/tyrus-standalone-client/2.1.2
 Se compila con:
javac -cp tyrus-standalone-client-2.1.2.jar Ejer3.java
Se ejecuta con:
java -cp .:tyrus-standalone-client-2.1.2.jar Ejer3 
 */

import java.io.*;
import java.net.URI;
import javax.websocket.*;

@ClientEndpoint
public class Ejer3 {

  int contador = 0;

  @OnOpen
  public void onOpen(Session Client_Session) {
    System.out.println ("--- Connection Successful " + Client_Session.getId());
    try {
      Client_Session.getBasicRemote().sendText("Start");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @OnMessage
  public String onMessage(String Client_Message, Session Client_Session) {
    try {
      System.out.println ("--- Message Received " + Client_Message);
      return "Hola mundo " + contador++; // Mensaje que se envía de respuesta al servidor
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  @OnClose
  public void onClose(Session Client_Session, CloseReason Close_Reason) {
    System.out.println("--- Session ID: " + Client_Session.getId());
    System.out.println("--- Closing Reason: " + Close_Reason);
  }

  public static void main(String[] args) {
    WebSocketContainer container=null;//
    Session session=null;
    try{
      container = ContainerProvider.getWebSocketContainer(); 

      session=container.connectToServer(Ejer3.class, URI.create("ws://localhost:8080/")); 

      // Bucle infinito mandando y recibiendo mensajes
      while(true) {}
    } catch (Exception e) {
      e.printStackTrace();
    }
    finally{
      if(session!=null){
        try {
          session.close();
        } catch (Exception e) {     
          e.printStackTrace();
        }
      }         
    } 
  }

}
