'use strict'
const PORT = 8000;
const HOST = '127.0.0.1';

let tipo = '';
let nombre = '';
let mensaje = '';

if(process.argv[2] === 'lista') {
  tipo = 'lista';
} else if(process.argv[2] === 'mensaje') {
  nombre = process.argv[3];
  mensaje = process.argv[4];
  tipo = 'mensaje';
}

const dgram = require('node:dgram');

const a = {'nombre': nombre, 'mensaje': mensaje, 'tipo': tipo}

const message = new Buffer.from(JSON.stringify(a));

const client = dgram.createSocket('udp4');

if(tipo === 'lista') {
  client.on('message', (msg, rinfo) => {
    console.log('Mensaje: ' + msg + " recibido de " + rinfo.address + ':' + rinfo.port);
    const lista = JSON.parse(msg);
    lista.forEach(
      (item) => {
        console.log(item.nombre + ': ' + item.mensaje);
      }
    );
    client.close();
  });
}

client.send(message, 0, message.length, PORT, HOST, function(err, bytes) {
  if (err) throw err;
  console.log('UDP message sent to ' + HOST +':'+ PORT);
  if(tipo === 'mensaje') client.close();
});
