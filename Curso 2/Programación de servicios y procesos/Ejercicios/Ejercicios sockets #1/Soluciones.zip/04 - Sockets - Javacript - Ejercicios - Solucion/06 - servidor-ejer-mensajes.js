'use strict'

const dgram = require('node:dgram');
const server = dgram.createSocket('udp4');

const mensajes = []

server.on('error', (err) => {
  console.log('Error:\n' + err.stack);
  server.close();
});

server.on('message', (msg, rinfo) => {
  console.log('Mensaje: ' + msg + " recibido de " + rinfo.address + ':' + rinfo.port);
  const cliente = JSON.parse(msg);
  if(cliente.tipo === 'lista') {
    const message = new Buffer.from(JSON.stringify(mensajes));
    server.send(message, 0, message.length, rinfo.port, rinfo.address, function(err, bytes) {
      if (err) throw err;
      console.log('UDP message sent to ' + rinfo.address +':'+ rinfo.port);
    });
  } else if(cliente.tipo === 'mensaje') {
    mensajes.push(cliente);
  }
});

server.on('listening', () => {
  const address = server.address();
  console.log("Escuchando en " + address.address + ":"+ address.port);
});

server.bind(8000);
