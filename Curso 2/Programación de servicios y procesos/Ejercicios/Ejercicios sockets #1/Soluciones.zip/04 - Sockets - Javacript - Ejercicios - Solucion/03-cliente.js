'use strict'
const net = require("net");

const host = "127.0.0.1";
const port = 5000;

const client = net.createConnection(port, host, () => {
  console.log("Connected");
  const a = {'usuario': 'admin', 'password': '12345' }
  client.write(JSON.stringify(a));
});

client.on("data", (data) => {
  console.log("Received: " + data);
  const resultado = JSON.parse(data);
  console.log(resultado.resultado)
  client.end();
});

client.on("error", (error) => {
  console.log("Error: " + error.message);
});

client.on("close", () => {
  console.log("Connection closed");
});
