'use strict'
const PORT = 8000;
const HOST = '127.0.0.1';



const dgram = require('node:dgram');

const a = {'usuario': 'admin', 'password': '12345' }

const message = new Buffer.from(JSON.stringify(a));

const client = dgram.createSocket('udp4');

client.on('message', (msg, rinfo) => {
  console.log('Mensaje: ' + msg + " recibido de " + rinfo.address + ':' + rinfo.port);
  const resultado = JSON.parse(msg);
  console.log(resultado.resultado); 
  client.close();
});

client.send(message, 0, message.length, PORT, HOST, function(err, bytes) {
  if (err) throw err;
  console.log('UDP message sent to ' + HOST +':'+ PORT);
});
