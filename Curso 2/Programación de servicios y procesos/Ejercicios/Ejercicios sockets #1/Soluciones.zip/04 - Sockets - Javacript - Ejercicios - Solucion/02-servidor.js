'use strict'

const dgram = require('node:dgram');
const server = dgram.createSocket('udp4');


server.on('error', (err) => {
  console.log('Error:\n' + err.stack);
  server.close();
});

server.on('message', (msg, rinfo) => {
  console.log('Mensaje: ' + msg + " recibido de " + rinfo.address + ':' + rinfo.port);
  const cliente = JSON.parse(msg);
  let resultado = 'Acceso denegado';
  if(cliente.usuario === 'admin' && cliente.password === '12345') {
    resultado = 'Acceso concedido';
  }
  const message = new Buffer.from(JSON.stringify({'resultado': resultado}));
  server.send(message, 0, message.length, rinfo.port, rinfo.address, function(err, bytes) {
    if (err) throw err;
    console.log('UDP message sent to ' + rinfo.address +':'+ rinfo.port);
  });

});

server.on('listening', () => {
  const address = server.address();
  console.log("Escuchando en " + address.address + ":"+ address.port);
});

server.bind(8000);
