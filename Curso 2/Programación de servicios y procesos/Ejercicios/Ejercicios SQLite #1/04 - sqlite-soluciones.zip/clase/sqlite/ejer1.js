const sqlite3 = require('sqlite3')

let db = new sqlite3.Database('./ejer1.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, 
	(err) => {
		if (err) {
			console.log("Error: " + err)
		} else {
			crearBase(db);
		}
	}
);

function crearBase(db) {
	db.exec(
     `
        create table if not exists usuarios (
           usuario text primary key not null,
           edad integer not null
        );
	create table if not exists telefonos (
           usuario text not null,
           telefono text not null
        );
     `
     , (err)  => {
        if(err) { 
            console.log("Error: " + err);
        } else {
		insertarValore(db)
	}
    });
}

