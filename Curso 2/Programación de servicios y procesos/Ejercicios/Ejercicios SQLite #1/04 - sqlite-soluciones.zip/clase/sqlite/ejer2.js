const sqlite3 = require('sqlite3')

let db = new sqlite3.Database('./ejer1.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, 
	(err) => {
		if (err) {
			console.log("Error: " + err)
		} else {
			insertarValores(db);
		}
	}
);


function insertarValores(db) {
	db.all(
		`
			insert into telefonos values (?, ?)
		`,
		"pepe", "555",
		(err) => {
			if(err) {
				console.log("Error: " + err)
			}
		}
	);
	db.all(
		`
			insert into usuarios values (?, ?)
		`,
		"pepe", 55,
		(err) => {
			if(err) {
				console.log("Error: " + err)
			}
		}
	);
}
