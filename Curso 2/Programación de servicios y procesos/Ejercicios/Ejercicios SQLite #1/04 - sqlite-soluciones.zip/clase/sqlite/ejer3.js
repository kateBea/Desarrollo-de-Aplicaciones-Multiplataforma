const sqlite3 = require('sqlite3')

let db = new sqlite3.Database('./ejer1.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, 
	(err) => {
		if (err) {
			console.log("Error: " + err)
		} else {
			consultarValores(db);
		}
	}
);


function consultarValores(db) {
	db.all(
		`
			select usuarios.usuario, edad, telefono from usuarios, telefonos
			where usuarios.usuario = telefonos.usuario;
		`,
		(err, rows) => {
			if(err) {
				console.log("Error: " + err)
			} else {
				rows.forEach( (row) => {
					let salida = row.usuario
					salida += ' '
					salida += row.edad
					salida += ' '
					salida += row.telefono
					console.log(salida)
				
				})
			}
		}
	);
}
