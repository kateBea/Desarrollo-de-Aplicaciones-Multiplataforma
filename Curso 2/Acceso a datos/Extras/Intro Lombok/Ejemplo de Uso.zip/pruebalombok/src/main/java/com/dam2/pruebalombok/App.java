package com.dam2.pruebalombok;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import lombok.var;
import lombok.extern.java.Log;




/**
 * Hello world!
 *
 */

public class App 
{
    public static void main( String[] args )
    {
    	List<Usuario> usuarios;
    	Comparator<Usuario> comparador;
    	
    	Usuario usu = Usuario.builder().
    							dni("001").
    							nombre("el tato").
    							edad(10).
    							amigo("yo").
    							amigo("tu").
    							build();
    	
    	var otrousu  = Usuario.builder().
    							dni("002").
    							edad(20).
    							amigo("yo").
    							build();
    	
    	otrousu.setNombre("miguel");
    	
    	System.out.println(usu);
        System.out.println(otrousu);
        System.out.println(usu.equals(otrousu)?"son iguales":"no son iguales");
        
        //No se puede ejecutar
        // amigos es inmutable
        //usu.getAmigos().add("el"); 
        usu.addAmigo("el");
        
        // Mostrar el usuario que tiene más amigos
        usuarios = new ArrayList<>();
        usuarios.add(usu);
        usuarios.add(otrousu);
        
        //comparador = (u1,u2) -> u1.getAmigos().size() - u2.getAmigos().size();
        comparador = new CompararPorNumeroDeAmigos();
        usuarios.sort(comparador.reversed());
        
        System.out.println("el usuario con más amigos es :");
        System.out.println(usuarios.get(0));
        
        
        // alternativa
        usuarios.stream().max(comparador).ifPresent(System.out::println);
    }
}
