package com.dam2.pruebalombok;

import java.util.Comparator;

public class CompararPorNumeroDeAmigos implements Comparator<Usuario> {

	@Override
	public int compare(Usuario u1, Usuario u2) {
		// TODO Auto-generated method stub
		return u1.getAmigos().size() - u2.getAmigos().size();
	}

}
