package com.dam2.pruebalombok;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.Singular;
import lombok.ToString;

//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString


@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)

public class Usuario {
	
	@EqualsAndHashCode.Include 
	private String dni;
	
	private String nombre;
	private int edad;
	
	@Singular 
	List<String> amigos;
	
	public void addAmigo (String amigo)
	{
		
		if (amigos != null)
		{
			amigos = new ArrayList<>(amigos);
		
			amigos.add(amigo);
		}
	}

}
