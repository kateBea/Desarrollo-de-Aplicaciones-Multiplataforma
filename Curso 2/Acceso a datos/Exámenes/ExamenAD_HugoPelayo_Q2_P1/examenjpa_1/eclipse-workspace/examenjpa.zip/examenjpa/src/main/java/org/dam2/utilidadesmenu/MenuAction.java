package org.dam2.utilidadesmenu;

public interface MenuAction {
	
	public void doMenuAction ();

}
