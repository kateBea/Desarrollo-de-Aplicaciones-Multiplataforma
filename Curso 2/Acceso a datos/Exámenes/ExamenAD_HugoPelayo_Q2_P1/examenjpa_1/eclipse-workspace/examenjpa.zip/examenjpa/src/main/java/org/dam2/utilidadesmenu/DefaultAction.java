package org.dam2.utilidadesmenu;



public class DefaultAction implements MenuAction {

	@Override
	public void doMenuAction() {
		// TODO Auto-generated method stub
		
	}

}
