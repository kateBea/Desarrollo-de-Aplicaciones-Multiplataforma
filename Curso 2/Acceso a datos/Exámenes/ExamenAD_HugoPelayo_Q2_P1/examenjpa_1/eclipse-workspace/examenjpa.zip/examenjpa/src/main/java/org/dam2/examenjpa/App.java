package org.dam2.examenjpa;

import org.dam2.modelo.MisDatos;
import org.dam2.utilidadeshibernate.GenericJPADAO;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	GenericJPADAO <MisDatos,Integer>  misDatosDAO;
    	String PERSISTENCE_UNIT = "examen";
    	MisDatos datos;
    	
    	misDatosDAO = new GenericJPADAO<>(MisDatos.class, PERSISTENCE_UNIT);
    	
    	datos = MisDatos.builder().id(1).nombre("001").build();
    	
       misDatosDAO.save(datos);
       
       misDatosDAO.findAll().forEach(System.out::println);
        
    }
}
