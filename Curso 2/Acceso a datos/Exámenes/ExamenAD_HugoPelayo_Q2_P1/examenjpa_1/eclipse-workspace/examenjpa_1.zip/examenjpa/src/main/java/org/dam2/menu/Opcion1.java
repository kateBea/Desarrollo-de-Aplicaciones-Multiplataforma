package org.dam2.menu;

import lombok.experimental.SuperBuilder;

@SuperBuilder
public class Opcion1 extends OpcionMenu {
	
	@Override
	public void accion() {
		
		
	}

}
