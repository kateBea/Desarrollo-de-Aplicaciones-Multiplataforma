package org.dam2.utilidadesmenu;

public class Salir extends MenuItem {

	public Salir ()
	{
		super ("Salir", AppMenu.SALIR, ()->{});
		
	}
	
}
