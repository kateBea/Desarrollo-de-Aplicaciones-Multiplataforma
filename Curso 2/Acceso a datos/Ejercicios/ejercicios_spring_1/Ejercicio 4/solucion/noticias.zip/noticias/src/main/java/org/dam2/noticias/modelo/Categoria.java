package org.dam2.noticias.modelo;

public enum Categoria {
	DEPORTES, POLITICA,ECONOMIA;

}
