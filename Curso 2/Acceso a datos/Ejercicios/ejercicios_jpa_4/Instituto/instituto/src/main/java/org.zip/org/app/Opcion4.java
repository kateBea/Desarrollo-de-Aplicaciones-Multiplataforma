package org.app;

import lombok.experimental.SuperBuilder;

@SuperBuilder
public class Opcion4 extends OpcionMenu {@Override
	public void accion() {
		// TODO Auto-generated method stub
		
	}

}
