package org.utilidades;

import java.time.LocalDate;
import java.util.Set;
import java.util.TreeSet;

import org.app.Contexto;
import org.instituto.Estudiante;
import org.instituto.Instituto;
import org.instituto.Persona;
import org.instituto.Profesor;
import org.instituto.TipoEstudio;

public class LecturaConsola {
	public static Persona leerPersona() {
		final String tipoPersona = Input.leerCadena("Introduce el tipo de integrante (P -> Profesor, E -> Estudiante)");
		
		
		return switch (tipoPersona) {
			case "P" -> leerProfesor();
			case "E" -> leerEstudiante();
			default -> null;
		};
	}
	
	public static Estudiante leerEstudiante() {
		Estudiante resultado = null;
		
		final String nif = Input.leerCadena("NIF: ");
		final String nombre = Input.leerCadena("Nombre: ");
		final String poblacion = Input.leerCadena("Población: ");
		final String nacimiento = Input.leerCadena("Fecha nacimiento (YYYY-MM-DD): ");
		
		final String curso = Input.leerCadena("Curso: ");
		final String grupo = Input.leerCadena("Grupo: ");
		final String esDelegado = Input.leerCadena("¿Es delegado? (S/n): ");
		final String tipoEstudios = Input.leerCadena("Estudios (ESO, BACH, FPS, FPM): ");
		
		resultado = Estudiante.builder()
			.nif(nif)
			.nombre(nombre)
			.poblacion(poblacion)
			.fechaNacimiento(LocalDate.parse(nacimiento))
			.curso(curso)
			.grupo(grupo)
			.delegado(esDelegado.equalsIgnoreCase("S"))
			.tipoEstudios(TipoEstudio.fromStr(tipoEstudios))
			.build();
		
		return resultado;
	}
	
	public static Profesor leerProfesor() {
		Profesor resultado = null;
		
		final String nif = Input.leerCadena("NIF: ");
		final String nombre = Input.leerCadena("Nombre: ");
		final String poblacion = Input.leerCadena("Población: ");
		final String nacimiento = Input.leerCadena("Fecha nacimiento (YYYY-MM-DD): ");
		
		final String nombreDpt = Input.leerCadena("Nombre departamento: ");
		final String despacho = Input.leerCadena("Nombre despacho: ");
		
		resultado = Profesor.builder()
			.nif(nif)
			.nombre(nombre)
			.poblacion(poblacion)
			.fechaNacimiento(LocalDate.parse(nacimiento))
			.nombreDept(nombreDpt)
			.despacho(despacho)
			.build();
		
		return resultado;
	}
	
	public static Instituto leerInstituto() {
		Instituto insti = null;
		// Leer datos del instituto
		final String codigo = Input.leerCadena("Código de instituto: ");
		
		if (Contexto.getDaoInstituto().findById(codigo).isPresent()) {
			System.err.println("El instituto con código " + codigo + " ya existe.");
			return insti;
		}
		
		final String nombre = Input.leerCadena("Nombre de instituto: ");
		final String telefono = Input.leerCadena("Teléfono de instituto: ");
		
		final String cp = Input.leerCadena("Código postal: ");
		final String poblacion = Input.leerCadena("Población: ");
		final String calle = Input.leerCadena("Calle: ");
			
		// Leer integrantes
		String seguir = null;
		Set<Persona> personas = new TreeSet<>();
		do {
			personas.add(leerPersona());
			
			seguir = Input.leerCadena("Leer otro integrante (S/n)");
		} while (seguir.equalsIgnoreCase("S"));
		
		
		return insti;
	}
}
