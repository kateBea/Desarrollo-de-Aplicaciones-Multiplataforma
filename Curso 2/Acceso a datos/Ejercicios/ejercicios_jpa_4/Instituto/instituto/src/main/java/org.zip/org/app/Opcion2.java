package org.app;

import java.util.List;
import java.util.Optional;

import org.instituto.Estudiante;
import org.instituto.Profesor;
import org.utilidades.Input;

import lombok.experimental.SuperBuilder;

@SuperBuilder
public class Opcion2 extends OpcionMenu{
	
	@Override
	public void accion() {
		final String nif = Input.leerCadena("Introduce el NIF del profesor: ");
		
		Optional<Profesor> result = Contexto.getDaoProfesor().findById(nif);
		
		if (result.isEmpty()) {
			System.err.println("El profesor con NIF " + nif + " no existe.");
			return;
		}
		
		List<Estudiante> estudiantesProfesor = result.get().getEstudiantes();
		List<Profesor> profesores = Contexto.getDaoProfesor().findAll();
		
		int indiceProfeActual = 0;
		for (Estudiante estudiante : estudiantesProfesor) {
			// Si no se puede asignar más estudiantes al profe actual avanzamos
			if (!profesores.get(indiceProfeActual).addEstudiante(estudiante)) {
				indiceProfeActual++;
			}
		}
		
		// Serializar a la base de datos
		for (Profesor profesor : profesores) {
			Contexto.getDaoProfesor().update(profesor);
		}
	}

}
