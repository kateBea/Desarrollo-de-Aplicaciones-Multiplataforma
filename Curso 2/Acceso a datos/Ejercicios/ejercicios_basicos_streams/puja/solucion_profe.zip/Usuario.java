package subasta;

public class Usuario {
	final private String nombre;
	private float credito;
	final private String email;
	
	public Usuario(String nombre, float credito, String email) {
	
		this.nombre = nombre;
		this.credito = credito;
		this.email = email;
		
	}


	public Usuario(String nombre, String email) {
		this (nombre, 50, email);
	}


	public String getNombre() {
		return nombre;
	}


	public float getCredito() {
		return credito;
	}
	
	
	
	public String getEmail() {
		return email;
	}


	public void incrementarCredito (float cantidad)
	{
		if (cantidad > 0)
			credito += cantidad;
	}
	
	public void decrementarCredito (float cantidad)
	{
		if (cantidad > 0)
			credito -= cantidad;
	}


	@Override
	public String toString() {
		return "Usuario [nombre=" + nombre + ", credito=" + credito + ", email=" + email + "]";
	}
	

}
