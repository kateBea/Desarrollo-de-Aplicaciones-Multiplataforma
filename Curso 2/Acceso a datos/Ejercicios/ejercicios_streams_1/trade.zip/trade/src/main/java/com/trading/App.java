package com.trading;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * Ejercicios streams.
 * Mirar el fichero de texto para los enunciados. 
 */
public class App {
    public static void main(String[] args) {
        Trader raoul    = Trader.builder().name("Raoul").city("Cambridge").build();
        Trader mario    = Trader.builder().name("Mario").city("Milan").build();
        Trader alan     = Trader.builder().name("Alan").city("Cambridge").build();
        Trader brian    = Trader.builder().name("Brian").city("Cambridge").build();

        List<Transaction> transactions = Arrays.asList(
            Transaction.builder().trader(brian).year(2011).value(300).build(),
            Transaction.builder().trader(raoul).year(2012).value(1000).build(),
            Transaction.builder().trader(raoul).year(2011).value(400).build(),
            Transaction.builder().trader(mario).year(2012).value(710).build(),
            Transaction.builder().trader(mario).year(2012).value(700).build(),
            Transaction.builder().trader(alan).year(2012).value(950).build()
        );


        // Q1: Find all transactions in the year 2011 and sort them by value (small to high).
        System.out.println("\nQuestion 1:");
        List<Transaction> lista1 = transactions.stream().
            filter(t -> t.getYear() == 2011).
            sorted(Comparator.comparing(Transaction::getValue)).
            toList();

        lista1.forEach(System.out::println);

        // Q2: What are all the unique cities where the traders work?
        System.out.println("\nQuestion 2:");
        List<String> lista2 = transactions.stream().
            map(transac -> transac.getTrader()).
            map(trader -> trader.getCity()).
            distinct().
            toList();

        lista2.forEach(System.out::println);

        // Find all traders from Cambridge and sort them by name.
        System.out.println("\nQuestion 3:");
        List<Trader> lista3 = transactions.stream().
            filter(transac -> transac.getTrader().getCity() == "Cambridge").
            map(transac -> transac.getTrader()).
            distinct().
            sorted(Comparator.comparing(Trader::getName)).
            toList();

        lista3.forEach(System.out::println);

        // Return a string of all traders' names sorted alphabetically.
        System.out.println("\nQuestion 4:");

        
        String listaTraders = transactions.stream().
            map(Transaction::getTrader).
            distinct().
            map(Trader::getName).
            sorted().
            reduce((t1, t2) -> t1 + ", " + t2).
            orElse("No hay datos");
        
        System.out.println(listaTraders);

        //  Are any traders based in Milan?
        System.out.println("\nQuestion 5:");


    }
}