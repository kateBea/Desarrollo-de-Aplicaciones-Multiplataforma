/*********************************************
Script de consultas del listado de ejercicios
descritos en el documendto Consultas BD_1.pdf

Autor: Hugo Pelayo
Fecha: 19 de enero de 2023
Fichero: Consultas BD_1.sql
**********************************************/

# Mostrar todas las bases de datos
SHOW DATABASES;

# Seleccionar la base de datos
USE World;

# Tablas de la base de datos en uso
SHOW TABLES;

# Mostrar campos de una tabla
DESCRIBE City;

# Seleccionamos toda la información de la tabla City
SELECT * 
FROM City;

# Selecciona solo la columna Name de la tabla City
SELECT Name
FROM City;

# Selecciona solo las columnas Name y CountryCode de la tabla City
SELECT Name, CountryCode
FROM City;

# Sleccionar las ciudades de Holanda
SELECT 	Name
FROM City
WHERE CountryCode = 'NLD';

/**********************************************
			     PARA PRACTICAR
**********************************************/

# 1. Los nombres y el Distrito de las ciudades españolas de la tabla City
SELECT Name AS "Nombre de Ciudad", District as "Provincia"
FROM City
WHERE CountryCode = 'ESP';

# 2. Todos los datos de las ciudades españolas de la tabla City
SELECT *
FROM City
WHERE CountryCode = 'ESP';

# 3. Los nombres de las ciudades de Madrid de la tabla City
SELECT Name AS "Nombre de Ciudad"
FROM City
WHERE CountryCode = 'ESP' AND District = 'Madrid';

# 4. Los nombres de las ciudades de Galicia de la tabla City
SELECT Name AS 'Nombre de Ciudad'
FROM City
WHERE CountryCode = 'ESP' AND District = 'Galicia';

# 5. Las ciudades con más de 5000000 habitantes
SELECT Name as 'Nombre de Ciudad', Population AS 'Población por Ciudad'
FROM City
WHERE Population > 5000000;

# 6. Las ciudades de España con más de 1000000 habitantes
SELECT Name as 'Nombre de Ciudad', Population AS 'Población por Ciudad'
FROM City
WHERE CountryCode = 'ESP' AND Population > 1000000;

# 7. Las ciudades de España o de Argentina con más de 1000000 habitantes
SELECT Name as 'Nombre de Ciudad', Population AS 'Población por Ciudad'
FROM City
WHERE (CountryCode = 'ESP' OR CountryCode = 'ARG') AND Population > 1000000;

# 8. Las tres primeras ciudades españolas en orden descendente
SELECT Name as 'Nombre de Ciudad'
FROM City
WHERE CountryCode = 'ESP'
ORDER BY Name DESC
LIMIT 3;