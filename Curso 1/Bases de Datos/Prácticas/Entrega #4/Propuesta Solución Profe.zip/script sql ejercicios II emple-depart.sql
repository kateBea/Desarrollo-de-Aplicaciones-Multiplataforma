
create database if not exists Tema5_ejercicios1_ampliacion;
use Tema5_ejercicios1_ampliacion;

create table emple (
emp_no 		integer not null primary key,
apellido	varchar(50) not null,
oficio 		varchar(20) not null,
dir			integer null,
fecha_alt	date not null,
salario		decimal(12,2) not null,
comision	integer null,
dept_no		smallint not null
);

create table depart (
dept_no		smallint not null primary key,
dnombre		varchar(50) not null,
loc			varchar(50) not null
);
 
alter table emple add constraint fk_emp_dpn foreign key (dept_no) 	references depart(dept_no) 	on update cascade on delete restrict;
alter table emple add constraint fk_emp_dir foreign key (dir)		references emple(emp_no)	on update cascade on delete restrict;


/*Como la tabla suministrada por el profesor está truncada, falta el jefe del empleado 'MUÑOZ' y  aparece un error al 
introducir los datos. Para evitarlo, he introducido una fila de control inventada con un departamento inventado*/

INSERT INTO depart(dept_no,dnombre,loc) values 	(10,'CONTABILIDAD','SEVILLA'),
						(20,'INVESTIGACION','MADRID'),
						(30,'VENTAS','BARCELONA'),
						(40,'PRODUCCION','BILBAO'),
                                                (00, 'control', 'control'); 

INSERT INTO emple(emp_no,apellido,oficio,fecha_alt,salario,dept_no) VALUES (7839,'REY','PRESIDENTE','1981/11/17',650000,10);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7566,'JIMENEZ','DIRECTOR',7839,'1981/04/02',386750,20);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7698,'NEGRO','DIRECTOR',7839,'1981/05/01',370500,30);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7788,'GIL','ANALISTA',7566,'1981/11/09',390000,20); 
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,comision,dept_no) VALUES (7844,'TOVAR','VENDEDOR',7698,'1981/09/08',195000,0,30);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7876,'ALONSO','EMPLEADO',7788,'1981/09/23',143000,20);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7900,'JIMENO','EMPLEADO',7698,'1981/12/03',1235000,30);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7902,'FERNANDEZ','ANALISTA',7566,'1981/12/03',390000,20);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7369,'SANCHEZ','EMPLEADO',7902,'1980/12/17',104000,20);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,comision,dept_no) VALUES (7499,'ARROYO','VENDEDOR',7698,'1980/02/20',208000,39000,30);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,comision,dept_no) VALUES (7521,'SALA','VENDEDOR',7698,'1981/02/22',162500,162500,30); 
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,comision,dept_no) VALUES (7654,'MARTIN','VENDEDOR',7698,'1981/09/29',162500,182000,30);
INSERT INTO emple(emp_no,apellido,oficio,fecha_alt,salario,dept_no) VALUES (7782,'DIR_DE_MUÑOZ','DIR_DE_MUÑOZ','1900/01/01',0,0);
INSERT INTO emple(emp_no,apellido,oficio,dir,fecha_alt,salario,dept_no) VALUES (7934,'MUÑOZ','EMPLEADO',7782,'1982/01/23',169000,10); 


