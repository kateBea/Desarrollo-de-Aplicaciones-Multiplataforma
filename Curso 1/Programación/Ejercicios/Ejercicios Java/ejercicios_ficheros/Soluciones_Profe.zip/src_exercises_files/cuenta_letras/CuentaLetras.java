package cuenta_letras;

import java.util.Scanner;
import java.io.*;

public class CuentaLetras {
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);


        System.out.print("Nombre fichero:");
        String nameFile = sc.nextLine();
        System.out.print ("Letra: ");
        String letter=sc.nextLine();

        try{
            FileReader myfile = new FileReader("cuenta_letras/" + nameFile);
            BufferedReader myfileBufferedReader = new BufferedReader(myfile);

            String line;
            int countLetter=0;

            do{

                line = myfileBufferedReader.readLine();
                if (line!=null)
                {
                    for (int i=0; i<line.length();i++)    {
                        if (line.substring(i, i+1).equals(letter)){
                            countLetter++;
                        }
                    }


                }
            }while (line!=null);
            myfile.close();
            System.out.println ("Cantidad de letras: " + countLetter);


        }catch (IOException ioe){
            System.out.println ("Error IOException");

        }catch (Exception e){
            System.out.println ("Error General");
        }
    }
}
