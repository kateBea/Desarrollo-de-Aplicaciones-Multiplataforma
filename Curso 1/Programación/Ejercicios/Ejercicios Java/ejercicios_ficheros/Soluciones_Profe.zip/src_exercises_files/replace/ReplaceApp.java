/*
 * Crea un programa en Java para reemplazar palabras en un fichero de texto,
guardando el resultado en nuevo fichero de texto
Para ello, se deberá crear un método ReplaceTextFile que reciba tres parámetros:
-el archivo
-la palabra a buscar
-la nueva palabra con la que se reemplaza la palabra buscada
El resultado se guardará en file_out.txt
 */
package replace;
import java.io.*;
public class ReplaceApp {
    public static void main(String[] args) {
        ReplaceTextFile("replace/prueba.txt", "hola", "adios");
    }
    public static void ReplaceTextFile (String urlFile, 
                        String textReplace, String newText){
    
        try{
            // streams para la lectura
            FileReader myFileRd = new FileReader (urlFile);
            BufferedReader myfileRdBufferReader = new BufferedReader(myFileRd);

            //para escribir
            FileWriter myFileWr = new FileWriter("replace/file_out.txt");
            
            String line = " ";

            //proceso lectura/escritura

            do{
                line = myfileRdBufferReader.readLine();
                if (line!=null){
                    //reemplazo
                    line = line.replace(textReplace, newText);
                    myFileWr.write (line + System.lineSeparator());

                }
            }while (line!=null);
            //cierro
            myFileWr.close();
            myfileRdBufferReader.close();


        }catch (IOException ioe){
            System.out.println (ioe);

        }catch (Exception e){
            System.out.println (e);

        }

    }
}
