/* Ejercicios II Ficheros */

package writing_files;

import java.io.FileWriter;

import java.io.PrintWriter;
import java.util.Scanner;
import java.io.IOException;
import java.util. Scanner;

public class exercise01 {
    public static void main(String[] args) {

        String line;
        Scanner sc = new Scanner(System.in);
        try{
            FileWriter myFileWriter = new FileWriter("writing_files/file01.txt", true);
            PrintWriter pw = new PrintWriter(myFileWriter);
            do{
                System.out.print ("Escriba una línea: ");
                line = sc.nextLine();
                if (!line.equals(""))
                    pw.write(line + System.lineSeparator());

            }while (!line.equals(""));

            //cerramos stream
            pw.close();
            sc.close();

        }catch (IOException ioe){
            System.out.println ("Error IO: " + ioe);

        }catch (Exception e){
            System.out.println ("Error Excepcion general: " + e);
            
        }
    }
}
