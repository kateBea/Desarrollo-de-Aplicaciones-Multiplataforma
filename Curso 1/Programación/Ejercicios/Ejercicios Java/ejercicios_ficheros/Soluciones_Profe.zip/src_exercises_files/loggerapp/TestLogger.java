package loggerapp;
public class TestLogger {
    public static void main(String[] args) {
        Logger.Write("loggerapp//text_loger.txt", "Hola");
        Logger.Write("loggerapp//text_loger.txt", "Ya queda menos para las vacas");
        Logger.Write("loggerapp//text_loger.txt", "¡ÁNIMO!");
    }
}
