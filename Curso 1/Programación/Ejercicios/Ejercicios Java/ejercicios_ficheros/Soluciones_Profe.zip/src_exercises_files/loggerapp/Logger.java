package loggerapp;

import java.io.FileWriter;
import java.io.IOException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.time.Instant;

public class Logger {
    public static void Write (String nameFile, String text){

        try{
            // creamos stream para escribir
            FileWriter myFileWriter = new FileWriter(nameFile, true);
            PrintWriter pw = new PrintWriter (myFileWriter);

            // escribimos
            pw.write (Date.from(Instant.now() )+ " - "+ text + System.lineSeparator() );

            //cerramos
            pw.close();

        }catch (IOException ioe){
            System.out.println (ioe);

        }catch (Exception e){
            System.out.println (e);


        }


    }
}
