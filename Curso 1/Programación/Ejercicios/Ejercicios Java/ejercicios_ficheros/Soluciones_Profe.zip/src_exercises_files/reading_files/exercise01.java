/*
 * Crea un programa en Java exercise01.java dentro del paquete "reading_files"
 * Se deberá consultar al usuario por consola el nombre del fichero que desea leer
 * A continuación, se mostrará el contenido del mismo
 * Nota: usar Scanner para leer el nombre del fichero y las clases FileReader, BufferReader para leer fichero
 */
package reading_files;

import java.util.Scanner;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;

public class exercise01 {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        String nameFile;

        //pedimos nombre fichero
        System.out.print("Escribe nombre fichero desea leer: ");
        nameFile = sc.nextLine();

        try{
            //creamos los streams para leer el fichero
            FileReader myfile = new FileReader("reading_files/"+nameFile);
            BufferedReader myfileBufferReader = new BufferedReader(myfile);
            String line = " ";
                
            //procesamos lectura
            do{
                line = myfileBufferReader.readLine();
                if (line!=null)
                    System.out.println (line); //mostramos el contenido de la línea que ha leído

            }while (line!=null);

            //cerrar 
            myfileBufferReader.close();
            sc.close();

        }catch (IOException ioe){
                System.out.print("Error IO: " + ioe);
        }catch (Exception e){
            System.out.print("Excepción general: " + e);
        }

        
    }
}
