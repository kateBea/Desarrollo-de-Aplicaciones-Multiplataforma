/* Fecha: 14-11-22
 * Ej05 mostrar del 100 al 0 de 7 en 7
 * 
 */
import java.io.*;
public class Ejercicio05_Numeros7 {
    public static void main (String [] arg) throws IOException{
        for (int i=100; i>=0; i-=7) //el for cuando es solo una sentencia podemos ahorrar {}
            System.out.println (i);

    }
}
