/* Fecha: 14--11-22
 * Ej04: pedir numero N mostrar nums de 1 a N
 * Se supone que N>1
 */
import java.io.*;
public class Ejercicio04_Nums_N {
    public static void main (String[] argumentos) throws IOException{
        //Declaración vbles
        BufferedReader lector = new BufferedReader (new InputStreamReader(System.in));

        int num, i;

        System.out.print ("Escribe un nº pf: ");
        num = Integer.parseInt(lector.readLine());

        i = 1;

        if (num<0)
            System.out.print ("N debe ser positivo");
            
        while (i<=num){
            System.out.println(i);
            i++; //equivale a i = i + 1
        }

    }
}
