/* Fecha: 14-11-22
 * Autor:RLR
 * Ej02: pedir nums hasta que introduzca 0. Para cad anum indicar si es par/impar
 */
import java.io.*;
public class Ejercico02_Par_Impar {
    
    public static void main (String[] argumentos) throws IOException{
        //Declaración variables

        BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
        int num;

        System.out.print ("Escribe nº: ");
        num = Integer.parseInt(lector.readLine());

        while (num!=0){ //mientras numero leido sea diferente de 0, se comprobara si es par/impar
            if (num%2==0){
                System.out.println("Par");
            }else{
                System.out.println("Impar");
            }
            //volvemos a pedir número
            System.out.print ("Escribe nº: ");
            num = Integer.parseInt(lector.readLine());
        }

    }
}
