/* Fecha: 14-11-22
 * Autor: RLR
 * Ej01: pedir nº, mostrar cuadrado. Parar cuando se escribe nº negativo 
 *  */
import java.io.*;
public class Ejercicio01_Cuadrado{

    public static void main (String[] argumentos) throws IOException{
        //Declaración de variables
        BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
        int num, cuadrado; //para leer numero
        
        System.out.println ("Escribe nº: ");
        num = Integer.parseInt(lector.readLine());

        while (num>=0){
            cuadrado = num * num;
            System.out.println ("El cuadrado es " + cuadrado);
            System.out.println ("Escribe nº: ");
            num = Integer.parseInt(lector.readLine());
        }
    }
}