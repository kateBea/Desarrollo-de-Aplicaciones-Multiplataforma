/*
 * 
 * 
 * 
 */
import java.io.*;
public class Ejercico06_Datos_Num {
    public static void main (String [] arg) throws IOException{
        //Declaración variables
        BufferedReader lector = new BufferedReader (new InputStreamReader(System.in));
        int num, cuantos_positivos, cuantos_negativos, cuantos_ceros, suma_negativos, suma_positivos;


        //inicializar variables
        cuantos_positivos =0;
        cuantos_negativos =0;
        cuantos_ceros =0;

        suma_positivos=0;
        suma_negativos =0;


        for (int i=1; i<=10; i++){
            System.out.println ("Escribe número pf: ");
            num = Integer.parseInt (lector.readLine());

            if (num == 0){ //si el num es cero
                cuantos_ceros++; // equivale cuantos_ceros = cuantos_Ceros + 1
            }else if (num > 0){
                cuantos_positivos++; // equivale a cuantos_positivos =cuantos_positivos +1
                suma_positivos += num; //equivale suma_positivos = suma_positivos + num

            }else if (num <0){
                cuantos_negativos++;
                suma_negativos += num;
            }

        }

        //Mostramos los datos

        System.out.println ("Nº de ceros: " + cuantos_ceros);
        
        System.out.println("Nº de positivos: " + cuantos_positivos);
        if (cuantos_positivos!=0)
            System.out.println (" Promedio positivos " +(suma_positivos/cuantos_positivos));
        
        System.out.println("Nº de negativos: " + cuantos_negativos);
        if (cuantos_negativos!=0)
            System.out.println (" Promedio positivos " +(suma_negativos/cuantos_negativos));  
    }
}
