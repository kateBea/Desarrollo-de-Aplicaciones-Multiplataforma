/* Fecha: 14-11-22
 * Ejercicio 3: pedir nums hasta que escriba num negativo
 *              mostrar suma total, promedio y cuántos
 * 
 */

import java.io.*;
public class Ejercicio03_Nums {
    public static void main (String[] argumentos) throws IOException{
        //Declaración variables
        BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));
        int num, contador, suma;

        System.out.print ("Introduzca número, pf: ");
        num = Integer.parseInt(lector.readLine());

        contador = 0;
        suma = 0;
        while (num>0){ //mientras num sea positivo, contamos el numero
            contador = contador + 1;
            suma = suma + num;
            System.out.println ("Escribe número, pf: ");
            num = Integer.parseInt(lector.readLine());   
        }
        // Mostramos los resultados
        if (contador!=0){  //lo aseguramos porque en promedio dividir por 0 salta excepción de error
            System.out.println ("Nº de números positivos: " + contador);
            System.out.println ("Suma total de nums positivos: " + suma);
            System.out.println ("Promedio nums positivos: " + (suma/contador));
        }
        
    }
}
