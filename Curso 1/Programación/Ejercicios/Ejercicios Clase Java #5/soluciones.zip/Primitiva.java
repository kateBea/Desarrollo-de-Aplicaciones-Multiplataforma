import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

/******************************************************************
Primitiva:
Escribir un programa que simule el juego de la Primitiva.
Un módulo (método jugar) se encargará de pedir al usuario seis enteros entre el 1 y el 49 sin repetición
y los devolverá en un array, otro módulo (método sortear) generará un array de seis enteros al azar
entre el 1 y el 49 sin repetición y por último el método comprobar dirá el número de aciertos.
Además hay que escribir un método auxiliar imprimir que permita imprimir los arrays de las combinaciones.
 *******************************************************************/

public class Primitiva {

    public static void main(String args[]) throws IOException {
        int[] combiJugada;
        int[] combiGanadora;

        combiJugada = jugar();
        combiGanadora = sortear();
        int aciertos = comprobar(combiJugada, combiGanadora);
        System.out.print("Combinación jugada: ");
        imprimir(combiJugada);
        System.out.print("Combinación ganadora: ");
        imprimir(combiGanadora);
        System.out.println("Número de aciertos: " + aciertos);
    }

    public static int[] jugar() throws IOException {
        int[] combi = {0, 0, 0, 0, 0, 0};
        int valen = 0;
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        while (valen < 6) {
            System.out.println("Introduzca un número entre 1 y 49: ");
            int n = Integer.parseInt(entrada.readLine());
            if (n < 1 || n > 49) {            //Miramos si está entre 1 y 49
                System.out.println("Número inválido");
                continue;
            }
            if (Arrays.binarySearch(combi, n) >= 0) { //Miramos si está repetido
                System.out.println("Número repetido");
                continue;
            }
            combi[0] = n;       //lo ponemos el primero
            Arrays.sort(combi); //ordenamos
            valen++;            //y ya tenemos otro más
        }
        return combi;
    }

    public static int[] sortear() {
        int[] combi = {0, 0, 0, 0, 0, 0};
        int valen = 0;
        while (valen < 6) {
            int n = (int) (1 + 49 * Math.random());
            if (Arrays.binarySearch(combi, n) >= 0) { //Miramos si está repetido
                continue;
            }
            combi[0] = n;       //lo ponemos el primero
            Arrays.sort(combi); //ordenamos
            valen++;            //y ya tenemos otro más
        }
        return combi;
    }

    public static int comprobar(int[] a, int[] b) {
        int aciertos = 0;
        //ordenamos los dos arrays
        Arrays.sort(a);
        Arrays.sort(b);
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < b.length; j++) {
                if (a[i] == b[j]) {
                    aciertos++;
                }
            }
        }
        return aciertos;
    }

    public static void imprimir(int[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + ",");
        }
        System.out.println();
    }
}


