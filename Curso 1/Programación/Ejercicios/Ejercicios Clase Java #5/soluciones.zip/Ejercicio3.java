
/*
Escribir un programa que solicite una cadena y una letra y nos devuelva las posiciones que ocupa esa letra en la cadena
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejercicio3 {

    public static void main(String args[]) throws IOException {
        BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            System.out.println("\nTeclee una palabra o frase (Intro para salir): ");
            String palabra = entrada.readLine();
            if (palabra.equals("")) {
                return;
            }
            System.out.println("\nTeclee la letra a buscar: ");
            char letra = entrada.readLine().charAt(0);
            System.out.print("La letra " + letra + " se encuentra en las posiciones: ");
            for (int i = 0; i < palabra.length(); i++) {
                if (palabra.charAt(i) == letra) {
                    System.out.print(i + 1 + ", ");
                }
            }
        }
    }
}
