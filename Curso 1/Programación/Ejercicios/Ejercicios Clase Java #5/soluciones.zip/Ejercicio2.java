import java.util.Random;

public class Ejercicio2 {

    public static void main(String[] args) {
        Random rand = new Random();
        char letras[] = new char[50];
        int contador = 0;
        
        //generamos las letras
        for (int i = 0; i < letras.length; i++) {
            int numero = rand.nextInt(28)+97;
            letras[i] = (char) numero;            
        }
        //contamos las vocales
        for (int i = 0; i < letras.length; i++) {
            if (esVocal(letras[i])){
                contador++;
            }
        }
        
        System.out.println("Número de vocales: " + contador);
        
        //imprimimos el array
        for (int i = 0; i < letras.length; i++) {            
            System.out.print(letras[i] + " ");
        }
    }
    
    public static boolean esVocal(char c) {
        return (c=='a' || c=='e' || c=='i' || c=='o' || c=='u');
    }
}
