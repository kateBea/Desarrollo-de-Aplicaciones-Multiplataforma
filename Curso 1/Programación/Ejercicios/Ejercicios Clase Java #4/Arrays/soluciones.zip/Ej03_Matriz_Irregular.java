/*
   Programa en Java que permita crear una matriz 
   con las dimensiones que el usuario indique. 
   Podrá ser una matriz irregular 
*/
import java.util.Scanner;
public class Ej03_Matriz_Irregular {

    public static void main (String [] argumentos){
        Scanner sc = new Scanner(System.in);
        int filas, elementos;
        int [][] mat; //matriz irregular


        /***********************CREACIÓN MATRIZ IRREGULAR *************************************** */
        //preguntamos el nº filas para hacer el new
        System.out.print ("Escribe nº filas: ");
        filas = sc.nextInt();

        mat = new int [filas][];

        for (int f=0; f<mat.length; f++){ //recorremos las filas
            System.out.print ("Cuántos elementos tiene la fila " + (f+1) + ": ");
            elementos = sc.nextInt();
            //para la fila en la que estamos creamos los elementos
            mat[f] = new int[elementos];
            //ahora recorreremos los elementos para pedir valores
            for (int c=0; c<mat[f].length; c++){ //recorrer las columnas
                //pedimo valor
                System.out.print ("-Escriba valor: ");
                mat[f][c]=sc.nextInt();
            } //fin cols
        }//fin filas


        /***************** MOSTRAR LOS VALORES DE LA MATRIZ***************************** */
        System.out.println("Los valores de la matriz creada son: ");
        for (int f=0; f<mat.length;f++){
            for (int c=0; c<mat[f].length; c++){
                System.out.print (mat[f][c] + " ");
            }
            System.out.println("\n"); //salto línea
        }

        sc.close();
    }
    
}
