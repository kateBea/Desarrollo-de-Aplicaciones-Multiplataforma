/* Ej02
 * Programa en Java que genere 10 números aleatorios entre el 0 y el 15. 
 * A continuación, se solicita un número al usuario y se comprobará 
 * si dicho número está entre los generados de forma aleatoria.
 * 
 * Nota: se suponen numeros enteros
 */
import java.util.Math;
import java.util.Scanner;
public class Ej02_Array_Aleatorios {
    
    public static void imprimir (int v[]){
        //método que recibe un vector de números y 
        //lo muestra por pantalla
        System.out.print ("\t -Vector=====> ");
        for (int posicion=0; posicion<v.length; posicion++){
            System.out.print (v[posicion] + " ");
        }
        System.out.print("\n");
    }
    public static void leerDatos (int v[]){
        //método que recibe un vector de números
        //y vuelve a asignar 10 números aleatorios entre 0 y 15
        final int LIMITE_SUPERIOR = 15;
        for (int posicion =0; posicion < v.length ; posicion++){
            double aleatorio = Math.random() * (LIMITE_SUPERIOR +1); // math.randome()* 16 para 0 a 15
            v[posicion] = (int) Math.floor(aleatorio); //Math.floor quita decimales y luego convertimos a int
        }
        imprimir (v);

    }

    public static void ordenarBurbuja(int v[]) {
        /* recibe un vector de números y lo ordena */
        int temporal;
        for (int i = 0; i < v.length; i++) {
            for (int j = 0; j < v.length - 1; j++) {
                if (v[j] > v[j + 1]) {
                    temporal = v[j];
                    v[j] = v[j + 1];
                    v[j + 1] = temporal;
                }
            }
        }
    }

    public static boolean busquedaBinaria (int n, int v[]){
        //busca el valor n dentro del vector v
        //si lo encuentra devuelve TRUE sino devuelve FALSE
        int mitad;
        int limiteInferior = 0;
        int limiteSuperior = v.length - 1;

        boolean encontrado = false;

        int numeroBusqueda = n;

        while ((limiteInferior <= limiteSuperior) && (!encontrado)) {
            // calculamos la posición mitad
            mitad = (limiteInferior + limiteSuperior) / 2;

            if (v[mitad] == numeroBusqueda) { // ¡encontrado!
                encontrado = true;

            } else if (v[mitad] > numeroBusqueda) {
                // buscamos en la primera mitad
                limiteSuperior = mitad - 1;
            } else {
                // buscar en segunda mitad
                limiteInferior = mitad + 1;
            }
        }
        return encontrado;
    }
    public static void main (String[] argumentos){
        Scanner sc = new Scanner(System.in);

        final int MAX=10;

        int numeros[] = new int [MAX];

        //cargamos el vector números de aleatorios
        leerDatos (numeros);

        //solicitar num al usuario
        System.out.print("Escribe un nº: ");
        int num = sc.nextInt();

        //ordenamos vector y buscamos el valor
        ordenarBurbuja(numeros);
        if (busquedaBinaria (num, numeros)==true){
            System.out.println (" número encontrado ");
        }else{
            System.out.println (" número no encontrado ");
        }
    }
    
}
