/* Ej01
   Programa en Java que pida al usuario 10 números y 
   el método de ordenación que desea. 
   A continuación, mostrar números ordenados según el algoritmo elegido.
 Puedes crear un menú con los distintos algoritmos.
 * Fecha: 21 nov 22
 * * 
 */
import java.io.*;


public class Ej01_Arrays{


    public static void leerDatos (int v[]) throws IOException{
        //método que recibe un vector con números 
        //y lo vuelve a rellenar con nuevos números solicitados al usuario
        BufferedReader lector = new BufferedReader(new InputStreamReader (System.in));

        for (int posicion = 0; posicion < v.length ; posicion++){
            System.out.print ("\t - Escribe nº: ");
            v[posicion] = Integer.parseInt(lector.readLine());
        }


    }
    public static void ordenarBurbuja (int v[]){
        //método que recibe un vector de números
        // y los ordena de menor a mayor con el alg de la burbuja
        int temporal;
        for (int i = 0; i < v.length; i++) {
            for (int j = 0; j < v.length - 1; j++) {
                if (v[j] > v[j + 1]) {
                    //intercambia los valores
                    temporal = v[j]; //en temporal se deja valor momentaneamente
                    v[j] = v[j + 1];
                    v[j + 1] = temporal;
                }
            }
        }
        imprimir(v);

    }
    public static void ordenarInsercion (int v[]){
        int p, j;
        int aux;
        for (p = 1; p < v.length; p++) { // desde el segundo elemento hasta
            aux = v[p]; // el final, guardamos el elemento y
            j = p - 1; // empezamos a comprobar con el anterior
            while ((j >= 0) && (aux < v[j])) { // mientras queden posiciones y el
                // valor de aux sea menor que los
                v[j + 1] = v[j]; // de la izquierda, se desplaza a
                j--; // la derecha
            }
            v[j + 1] = aux; // colocamos aux en su sitio
        }
        imprimir(v);

    }
    public static void imprimir (int v[]){
        //método que recibe un vector de números y 
        //lo muestra por pantalla
        System.out.print ("\t -Vector=====> ");
        for (int posicion=0; posicion<v.length; posicion++){
            System.out.print (v[posicion] + " ");
        }
        System.out.print("\n");


    }
    public static void mostrarMenu() throws IOException{
        BufferedReader lector = new BufferedReader(new InputStreamReader (System.in));
        final int MAX= 6; //numero elementos del vector
        final int FIN = 5; // la opción SALIR del menú

        int opcion;
        int[] numeros = new int [MAX]; //vector con los números

        //presentamos el menú mientras que el usuario no pulse opción de Salir
        do{
            System.out.println ("************ MENU *****************************");
            System.out.println ("1. Leer datos vector");
            System.out.println ("2. Ordenar algoritmo burbuja");
            System.out.println ("3. Ordenar algorimo de inserción");
            System.out.println ("4. Mostrar vector");
            System.out.println ("5. Salir");
            System.out.print ("Opción: ");
            opcion = Integer.parseInt(lector.readLine());
            switch (opcion){
                case 1:
                    leerDatos(numeros);   
                    break;                 
                case 2:
                    ordenarBurbuja(numeros);
                    break;
                case 3:
                    ordenarInsercion(numeros);
                    break;
                case 4:
                    imprimir (numeros);
                    break;
                case 5:
                    System.out.println ("Hasta pronto");
                    break;
                default:
                    System.out.println ("Dato no válido. Pulse opción de 1 a 5.");
            }

        }while (opcion!=FIN);

    }
    public static void main (String [] argumentos) throws IOException{
        mostrarMenu();

    }



}