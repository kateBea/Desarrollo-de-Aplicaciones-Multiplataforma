/*
 * Ejemplo 02
 * Conexión de una base de datos que preguntamos al usuario
 * Creación de una tabla en la base de datos a la que nos conectamos
 * Previamente en Workbench ejecutamos una bd de pruebas
 * CREATE DATABASE testProgr;
   CREATE USER 'ruth'@'localhost' identified by 'PwdTest';
   GRANT ALL privileges on testProgr.* TO 'ruth';
 * 
 */
import java.io.*;
import java.sql.*;
public class App {
    static Connection conexion;
    static Statement sentencia;
    static ResultSet resultado;
    static BufferedReader lector = new BufferedReader(new InputStreamReader(System.in));

    static void  cargarDriver (){
        try{
            Class.forName ("com.mysql.cj.jdbc.Driver");
       }catch(Exception e){
            System.out.print ("No se pudo cargar el driver");
       }
    }
    static void establecerConexion() throws IOException{
       
        try{
            System.out.println ("Escriba el nombre de la base de datos");
            String nombreBD = lector.readLine();
            System.out.println ("Usuario: ");
            String user = lector.readLine();
            System.out.println ("Password: ");
            String pass = lector.readLine();
            String url = "jdbc:mysql://localhost:3306/"+nombreBD;
            conexion=DriverManager.getConnection(url, user, pass);

        }catch (IOException ioe){
            System.out.println ("Error establecer conexión " + ioe.getMessage());
        
        }catch(Exception e){
            System.out.println ("Error establecer conexión " + e.getMessage());
        }

    }
    static void crearTabla (){
        
        try{
            sentencia = conexion.createStatement(); //creamos objeto para poder ejecutar SQL
            sentencia.execute ("DROP TABLE IF EXISTS personas");
            sentencia.execute ("CREATE TABLE personas ( " +
                " DNI Varchar(15) not null primary key,"+
                " Nombre Varchar(50) not null,"+
                " Apellidos Varchar(50) not null, "+
                " Edad int)");
            System.out.print ("Tabla creada");
           
        }catch (SQLException sqlex){
            System.out.println ("Error creación tabla " + sqlex.getMessage());

        }catch (Exception e){
            System.out.println ("Error creación tabla " + e.getMessage());
        }


    }
    static void cerrarConexion(){
        try{
            sentencia.close();
            conexion.close();
        }catch (Exception e){
            System.out.println ("Error cierre conexión " + e.getMessage());            
        }
      
    }
    static void insert() throws IOException{
        try{
            // pedimos los valores de los campos

            System.out.println ("DNI: ");
            String dni = lector.readLine();
            System.out.println ("Nombre: ");
            String nombre = lector.readLine();
            System.out.println ("Apellidos: ");
            String apellidos = lector.readLine();
            System.out.println ("Edad: ");
            int edad = Integer.parseInt(lector.readLine());

            // insertamos


            sentencia.execute ("INSERT INTO personas " +
            " VALUES ('" + dni+ "', '"+ nombre + "', '"+ apellidos + "', "+ edad +")");
            System.out.print ("Registro dado de alta");
        }catch(SQLException sqle){
            System.out.println ("Error insertar  " + sqle.getMessage());       
        }
    }
    static void mostrar(){

        try{
            resultado = sentencia.executeQuery("SELECT * FROM personas");
            while (resultado.next()){ //recorremos el resultset registro a registro
                System.out.println ("DNI: " + resultado.getString("DNI"));
                System.out.println ("Nombre: " + resultado.getString("Nombre"));
                System.out.println ("Apellidos: " + resultado.getString("Apellidos"));
                System.out.println ("Edad: " + resultado.getInt("Edad"));
                

            }
        }catch (SQLException sqle){
            System.out.println ("Error mostrar  " + sqle.getMessage());    
        }catch (Exception e){
            System.out.println ("Error mostrar  " + e.getMessage());    
        }
    }
    public static void main(String[] args) throws Exception {       
       cargarDriver(); //1º cargamos el Driver MySQL
       establecerConexion(); //2º establecemos Conexión BD
       //3º establecemos 'dialogo' En este ej crear tabla 
       crearTabla(); 
       insert();
       mostrar();
       cerrarConexion(); //Por último, cerramos conexión

    }
}
